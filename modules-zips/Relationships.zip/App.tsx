import React, { useState, useEffect, useRef } from 'react';
import { 
  Heart, Users, Clock, CheckCircle, X, Menu, 
  Layers, Dna, Eye, EyeOff, Search, 
  GitMerge, Activity,
  ChevronRight, ChevronLeft, Projector, Maximize2, Minimize2,
  Trophy, Zap, HeartCrack,
  Star, AlertTriangle, RefreshCcw,
  MessageCircle, Target, RefreshCw, MessageSquare, Smartphone, Wrench, Briefcase, Send,
  Coffee, Smile, Frown, Meh, Filter, ArrowDown, PenTool, Baby, Timer, DollarSign, Scale, TrendingUp, TrendingDown,
  Sparkles, ThumbsUp, ThumbsDown, Camera, Palette, Car, BookOpen, Music, Gavel
} from 'lucide-react';

// ==========================================
// 1. DATA: LESSON CONTENT
// ==========================================

const lessons = [
  { id: 1, title: "01: Evolutionary Explanations", active: true, complete: true },
  { id: 2, title: "02: Physical Attractiveness", active: false, complete: false },
  { id: 3, title: "03: Self Disclosure", active: false, complete: false },
  { id: 4, title: "04: Filter Theory", active: false, complete: false },
  { id: 5, title: "05: Social Exchange Theory", active: false, complete: false },
  { id: 6, title: "06: Equity Theory", active: false, complete: false },
  { id: 7, title: "07: Rusbult's Investment Model", active: false, complete: false },
  { id: 8, title: "08: Duck's Phase Model", active: false, complete: false },
  { id: 9, title: "09: Virtual Relationships", active: false, complete: false },
  { id: 10, title: "10: Parasocial Relationships", active: false, complete: false },
];

const lesson1DoNow = [
  { id: 1, question: "Biological Approach: What is the main driver of behaviour according to evolution?", options: ["Happiness", "Survival and Reproduction", "Self-Actualisation"], correct: 1 },
  { id: 2, question: "Issues & Debates: Evolutionary explanations are an example of...", options: ["Biological Determinism", "Soft Determinism", "Cultural Relativism"], correct: 0 },
  { id: 3, question: "Genetics: How many chromosomes are in a human gamete (sex cell)?", options: ["46", "23", "2"], correct: 1 },
  { id: 4, question: "Methods: Which method allows researchers to study behaviour across 37 different cultures?", options: ["Lab Experiment", "Case Study", "Cross-Cultural Survey"], correct: 2 },
  { id: 5, question: "Year 1 Recap: Which attachment type is associated with 'cold' parenting?", options: ["Secure", "Insecure-Resistant", "Insecure-Avoidant"], correct: 2 }
];

// ==========================================
// 2. SHARED UI COMPONENTS
// ==========================================

interface PhaseHeaderProps {
  phase: string;
  title: string;
  icon: React.ElementType;
  time?: string;
  isPresentation: boolean;
}

const PhaseHeader: React.FC<PhaseHeaderProps> = ({ phase, title, icon: Icon, time, isPresentation }) => (
  <div className={`flex items-center justify-between border-b border-gray-700 transition-all ${isPresentation ? 'mb-4 pb-2' : 'mb-6 pb-4'}`}>
    <div className="flex items-center gap-3">
      <div className={`rounded-xl border border-pink-500/30 transition-all ${isPresentation ? 'p-2 bg-pink-900/50' : 'p-3 bg-pink-900/30'}`}>
        <Icon size={isPresentation ? 48 : 28} className="text-pink-400" />
      </div>
      <div>
        <h4 className={`font-bold text-pink-400 uppercase tracking-widest transition-all ${isPresentation ? 'text-lg mb-1' : 'text-[10px] mb-0.5'}`}>{phase}</h4>
        <h2 className={`font-bold text-gray-100 transition-all ${isPresentation ? 'text-5xl' : 'text-3xl'}`}>{title}</h2>
      </div>
    </div>
    {time && (
      <div className={`flex items-center gap-2 text-gray-500 font-mono bg-gray-900 rounded-full border border-gray-800 transition-all ${isPresentation ? 'text-xl px-5 py-2' : 'text-xs px-2 py-1'}`}>
        <Clock size={isPresentation ? 24 : 12} /> {time}
      </div>
    )}
  </div>
);

interface SlideProps {
  children: React.ReactNode;
  isPresentation: boolean;
}

const Slide: React.FC<SlideProps> = ({ children, isPresentation }) => (
  <div className={`flex flex-col h-full animate-fadeIn text-gray-100 mx-auto w-full transition-all duration-300 ${isPresentation ? 'p-6 max-w-[98vw] text-2xl' : 'p-8 max-w-7xl text-base'}`}>
    <div className={`flex-grow overflow-y-auto pr-2 custom-scrollbar flex flex-col ${isPresentation ? 'gap-6' : 'gap-6'}`}>
      {children}
    </div>
  </div>
);

interface Question {
  id: number;
  question: string;
  options: string[];
  correct: number;
}

const DoNowQuiz: React.FC<{ questions: Question[]; isPresentation: boolean }> = ({ questions, isPresentation }) => {
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [showResults, setShowResults] = useState(false);
  
  const handleSelect = (qId: number, optionIdx: number) => setAnswers(prev => ({...prev, [qId]: optionIdx}));
  const score = Object.keys(answers).reduce((acc, qId) => acc + (answers[Number(qId)] === questions[Number(qId)-1].correct ? 1 : 0), 0);

  return (
    <div className={`grid grid-cols-1 lg:grid-cols-2 h-full content-start transition-all ${isPresentation ? 'gap-12' : 'gap-6'}`}>
      <div className="space-y-4">
        <div className={`bg-pink-900/20 rounded-xl border border-pink-500/30 ${isPresentation ? 'p-10' : 'p-5'}`}>
          <h3 className={`font-bold text-white mb-2 ${isPresentation ? 'text-4xl' : 'text-lg'}`}>Task: Activation & Retrieval</h3>
          <p className={`text-gray-300 ${isPresentation ? 'text-2xl' : 'text-sm'}`}>Activate your psychological knowledge.</p>
        </div>
        <div className={`flex flex-col ${isPresentation ? 'gap-6' : 'gap-3'}`}>
           {!showResults ? (
             <>
              <button onClick={() => setShowResults(true)} disabled={Object.keys(answers).length < 5} className={`bg-pink-600 hover:bg-pink-500 disabled:opacity-50 text-white rounded-lg font-bold w-full transition-all shadow-lg ${isPresentation ? 'px-12 py-8 text-3xl' : 'px-8 py-3'}`}>Submit Answers</button>
              <button onClick={() => setShowResults(true)} className={`bg-gray-800 hover:bg-gray-700 text-gray-300 border border-gray-600 rounded-lg font-semibold w-full transition-all ${isPresentation ? 'px-12 py-6 text-2xl' : 'px-8 py-2 text-sm'}`}>Reveal All Answers</button>
             </>
           ) : (
            <div className={`bg-green-900/20 border border-green-500/50 rounded-lg w-full text-center animate-fadeIn ${isPresentation ? 'p-10' : 'p-4'}`}>
              <span className={`font-bold text-green-400 block mb-1 ${isPresentation ? 'text-6xl mb-4' : 'text-2xl'}`}>Score: {score} / 5</span>
              <span className={`text-gray-400 ${isPresentation ? 'text-2xl' : 'text-xs'}`}>Check corrections on the right.</span>
            </div>
           )}
        </div>
      </div>
      <div className="space-y-2 overflow-y-auto pr-2 custom-scrollbar max-h-full">
        {questions.map((q) => (
          <div key={q.id} className={`bg-gray-800 rounded-lg border border-gray-700 ${isPresentation ? 'p-6 mb-4' : 'p-3'}`}>
            <h4 className={`font-semibold text-gray-200 mb-1.5 ${isPresentation ? 'text-2xl mb-4' : 'text-xs'}`}>{q.id}. {q.question}</h4>
            {isPresentation ? (
              <div className="min-h-[40px]">
                {showResults && (
                   <div className="text-green-400 font-bold text-3xl animate-fadeIn mt-2 flex items-center gap-2">
                     <CheckCircle size={32}/> {q.options[q.correct]}
                   </div>
                )}
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-1.5">
                {q.options.map((opt, idx) => (
                  <button key={idx} onClick={() => !showResults && handleSelect(q.id, idx)} className={`rounded text-left transition-all px-3 py-1.5 text-xs ${showResults ? idx === q.correct ? "bg-green-900/40 border border-green-500 text-green-100" : answers[q.id] === idx ? "bg-red-900/40 border border-red-500 text-red-100" : "bg-gray-900/50 text-gray-600 opacity-50" : answers[q.id] === idx ? "bg-pink-600 text-white" : "bg-gray-900 hover:bg-gray-700 text-gray-400"}`}>{opt}</button>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

// ==========================================
// 3. SUB-COMPONENTS (LESSON SPECIFIC)
// ==========================================

const AFLCheckL1: React.FC<{ isPresentation: boolean }> = ({ isPresentation }) => {
  const [selected, setSelected] = useState<string | null>(null);
  return (
    <div className={`flex flex-col items-center justify-center h-full text-center max-w-4xl mx-auto ${isPresentation ? 'gap-12' : 'gap-8'}`}>
        <div className={`bg-gray-900 p-8 rounded-full border-4 border-pink-500/50`}>
            <Dna size={isPresentation ? 100 : 64} className="text-pink-400" />
        </div>
        <h3 className={`font-bold text-white ${isPresentation ? 'text-5xl' : 'text-3xl'}`}>Quick Check: Anisogamy</h3>
        <p className={`text-gray-300 ${isPresentation ? 'text-3xl' : 'text-lg'}`}>"Anisogamy refers to the differences between male and female sex cells. Because female eggs are rare and resource-heavy, females tend to be..."</p>
        
        <div className="grid grid-cols-3 gap-6 w-full">
            <button onClick={() => setSelected('choosy')} className={`p-6 rounded-xl border-2 transition-all ${selected === 'choosy' ? 'bg-green-900/50 border-green-500' : 'bg-gray-800 border-gray-600 hover:border-gray-400'}`}>
                <strong className={`block text-white ${isPresentation ? 'text-3xl' : 'text-xl'}`}>Choosier (Quality)</strong>
            </button>
            <button onClick={() => setSelected('promiscuous')} className={`p-6 rounded-xl border-2 transition-all ${selected === 'promiscuous' ? 'bg-red-900/50 border-red-500' : 'bg-gray-800 border-gray-600 hover:border-gray-400'}`}>
                <strong className={`block text-white ${isPresentation ? 'text-3xl' : 'text-xl'}`}>Promiscuous (Quantity)</strong>
            </button>
            <button onClick={() => setSelected('equal')} className={`p-6 rounded-xl border-2 transition-all ${selected === 'equal' ? 'bg-red-900/50 border-red-500' : 'bg-gray-800 border-gray-600 hover:border-gray-400'}`}>
                <strong className={`block text-white ${isPresentation ? 'text-3xl' : 'text-xl'}`}>Equal to Males</strong>
            </button>
        </div>
        
        {selected === 'choosy' && (
            <div className="animate-fadeIn bg-green-900/20 border-l-4 border-green-500 p-4 rounded text-green-300 font-bold text-xl">
                Correct. This is the basis of Intersexual Selection.
            </div>
        )}
        {(selected === 'promiscuous' || selected === 'equal') && (
            <div className="animate-fadeIn bg-red-900/20 border-l-4 border-red-500 p-4 rounded text-red-300 font-bold text-xl">
                Incorrect. High investment leads to choosiness.
            </div>
        )}
    </div>
  );
};

// --- EVO MATCH (TINDER STYLE) SIM (LESSON 1) ---

interface TinderProfile {
  id: number;
  name: string;
  age: number;
  job: string;
  bio: string;
  resources: number; // 0-100 (For Female Strategy)
  fertility: number; // 0-100 (For Male Strategy)
  traits: string[];
  gender: 'male' | 'female';
}

const getJobIcon = (job: string) => {
  switch(job) {
    case "CEO": return DollarSign;
    case "Investment Banker": return TrendingUp;
    case "Surgeon": return Activity;
    case "Nurse": return Heart;
    case "Architect": return PenTool;
    case "Artist": return Palette;
    case "Lawyer": return Gavel; 
    case "Teacher": return BookOpen;
    case "Influencer": return Smartphone;
    case "Model": return Camera;
    case "Student": return Coffee; 
    case "Unemployed": return Frown;
    case "Bus Driver": return Car;
    case "Musician": return Music;
    default: return Users;
  }
};

const generateProfiles = (): { males: TinderProfile[], females: TinderProfile[] } => {
  const maleJobs = [
    { title: "CEO", res: 95 }, { title: "Surgeon", res: 90 }, { title: "Architect", res: 85 },
    { title: "Teacher", res: 60 }, { title: "Artist", res: 40 }, { title: "Unemployed", res: 10 },
    { title: "Student", res: 20 }, { title: "Investment Banker", res: 98 }, { title: "Bus Driver", res: 45 },
    { title: "Musician", res: 30 }
  ];
  
  const femaleJobs = [
    { title: "Model", res: 80 }, { title: "Teacher", res: 60 }, { title: "Nurse", res: 65 },
    { title: "Lawyer", res: 85 }, { title: "Student", res: 20 }, { title: "Influencer", res: 70 },
    { title: "Artist", res: 45 }
  ];

  const maleNames = ["James", "John", "Rob", "Mike", "Will", "Dave", "Rich", "Joe", "Tom", "Charlie", "Alex", "Ben", "Dan", "Sam", "Chris"];
  const femaleNames = ["Mary", "Pat", "Jen", "Liz", "Barb", "Sue", "Jess", "Sarah", "Karen", "Emma", "Lucy", "Kate", "Anna", "Mia", "Zoe"];

  const males: TinderProfile[] = [];
  const females: TinderProfile[] = [];

  for (let i = 0; i < 50; i++) {
    const job = maleJobs[Math.floor(Math.random() * maleJobs.length)];
    const age = Math.floor(Math.random() * 40) + 18;
    const fertility = Math.max(0, 100 - (age * 1.5)); 
    males.push({
      id: i,
      name: maleNames[i % maleNames.length],
      age,
      job: job.title,
      bio: "Looking for loyalty.",
      resources: job.res + (Math.random() * 20 - 10),
      fertility,
      traits: job.res > 70 ? ["Ambitious", "Wealthy"] : ["Free Spirit", "Fun"],
      gender: 'male'
    });
  }

  for (let i = 0; i < 50; i++) {
    const job = femaleJobs[Math.floor(Math.random() * femaleJobs.length)];
    const age = Math.floor(Math.random() * 35) + 18;
    const fertility = age < 25 ? 90 + Math.random() * 10 : Math.max(0, 90 - ((age-25) * 3));
    females.push({
      id: i + 50,
      name: femaleNames[i % femaleNames.length],
      age,
      job: job.title,
      bio: "Looking for a serious partner.",
      resources: job.res,
      fertility,
      traits: age < 25 ? ["Youthful", "Energetic"] : ["Mature", "Established"],
      gender: 'female'
    });
  }

  return { males, females };
};

const EvoTinderSim: React.FC<{ isPresentation: boolean }> = ({ isPresentation }) => {
  const [strategy, setStrategy] = useState<'male' | 'female' | null>(null);
  const [profiles, setProfiles] = useState<TinderProfile[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [gameState, setGameState] = useState<'intro' | 'playing' | 'finished'>('intro');
  // Lazy initialization to ensure fresh profiles on mount
  const [gameData] = useState(() => generateProfiles());

  const startGame = (selectedStrategy: 'male' | 'female') => {
    setStrategy(selectedStrategy);
    setProfiles(selectedStrategy === 'male' ? gameData.females : gameData.males);
    setScore(0);
    setStreak(0);
    setCurrentIndex(0);
    setGameState('playing');
  };

  const handleSwipe = (direction: 'left' | 'right') => {
    const currentProfile = profiles[currentIndex];
    let points = 0;
    let msg = "";
    let isCorrect = false;

    if (strategy === 'female') {
      // Female Strategy: Maximise Resources
      if (direction === 'right') {
        if (currentProfile.resources > 60) {
          isCorrect = true;
          points = 100;
          msg = "RESOURCE ACQUIRED";
        } else {
          points = -50;
          msg = "LOW INVESTMENT";
        }
      } else {
        if (currentProfile.resources <= 60) {
          isCorrect = true;
          points = 50;
          msg = "AVOIDED POVERTY";
        }
      }
    } else {
      // Male Strategy: Maximise Fertility
      if (direction === 'right') {
        if (currentProfile.fertility > 65) {
          isCorrect = true;
          points = 100;
          msg = "FERTILITY HIGH";
        } else {
          points = -50;
          msg = "FERTILITY LOW";
        }
      } else {
         if (currentProfile.fertility <= 65) {
             isCorrect = true;
             points = 50;
             msg = "SAVED ENERGY";
         }
      }
    }

    if (isCorrect) {
        const newStreak = streak + 1;
        setStreak(newStreak);
        const multiplier = 1 + Math.floor(newStreak / 3) * 0.5;
        setScore(prev => prev + Math.floor(points * multiplier));
        if (newStreak > 1) msg += ` x${multiplier} COMBO!`;
    } else {
        setStreak(0);
        setScore(prev => prev + points);
    }

    setFeedback(msg);
    setTimeout(() => setFeedback(null), 1000);

    if (currentIndex >= 14) { // 15 rounds
      setGameState('finished');
    } else {
      setCurrentIndex(prev => prev + 1);
    }
  };

  const currentProfile = profiles[currentIndex];
  const ProfileIcon = currentProfile ? getJobIcon(currentProfile.job) : Users;

  return (
    <div className={`relative w-full max-w-4xl h-[600px] mx-auto bg-black font-retro rounded-lg border-4 ${strategy === 'male' ? 'border-blue-500' : strategy === 'female' ? 'border-pink-500' : 'border-gray-600'} overflow-hidden flex flex-col shadow-2xl`}>
      
      {/* SCANLINE OVERLAY - Moved here with pointer-events-none to prevent blocking interactions on parent */}
      <div className="absolute inset-0 z-50 retro-scanlines pointer-events-none opacity-50"></div>

      {/* INTRO SCREEN */}
      {gameState === 'intro' && (
        <div className="absolute inset-0 z-40 bg-black flex flex-col items-center justify-center p-8 text-center animate-fadeIn">
          <Heart size={64} className="text-pink-500 mb-4 animate-pulse" />
          <h2 className="text-3xl text-white mb-4 retro-text-shadow">LOVE_TERMINAL_v1.0</h2>
          <p className="text-green-400 mb-8 text-xs leading-loose max-w-md">
            > INITIALIZING MATING PROTOCOLS...<br/>
            > SELECT EVOLUTIONARY STRATEGY...
          </p>
          
          <div className="flex gap-4">
            <button onClick={() => startGame('male')} className="border-4 border-blue-500 bg-blue-900/20 p-6 hover:bg-blue-900/40 text-blue-400 hover:scale-105 transition-transform z-50 cursor-pointer">
                <div className="text-2xl mb-2">♂ MALE</div>
                <div className="text-[10px]">TARGET: FERTILITY</div>
            </button>
            <button onClick={() => startGame('female')} className="border-4 border-pink-500 bg-pink-900/20 p-6 hover:bg-pink-900/40 text-pink-400 hover:scale-105 transition-transform z-50 cursor-pointer">
                <div className="text-2xl mb-2">♀ FEMALE</div>
                <div className="text-[10px]">TARGET: RESOURCES</div>
            </button>
          </div>
        </div>
      )}

      {/* GAME OVER SCREEN */}
      {gameState === 'finished' && (
        <div className="absolute inset-0 z-40 bg-black flex flex-col items-center justify-center p-8 text-center animate-fadeIn">
           <Trophy size={64} className="text-yellow-400 mb-6" />
           <h2 className="text-2xl text-white mb-4">SIMULATION COMPLETE</h2>
           <div className="text-4xl text-yellow-400 mb-8 border-b-4 border-yellow-400 pb-2 px-8">
             SCORE: {score}
           </div>
           <div className="bg-gray-900 border-2 border-gray-700 p-4 max-w-lg mb-8">
             <p className="text-green-400 text-xs leading-relaxed text-left">
               > LOG_OUTPUT:<br/>
               {strategy === 'female' 
                 ? "FEMALE STRATEGY DETECTED. HIGH PRIORITY ON RESOURCE ACQUISITION SECURES OFFSPRING SURVIVAL. ALIGNS WITH BUSS (1989)." 
                 : "MALE STRATEGY DETECTED. HIGH PRIORITY ON YOUTH INDICATES FERTILITY. MAXIMIZES GENETIC PROPAGATION."}
             </p>
           </div>
           <button onClick={() => setGameState('intro')} className="bg-white text-black font-bold px-6 py-4 text-sm hover:bg-gray-200 cursor-pointer z-50">REBOOT SYSTEM</button>
        </div>
      )}

      {/* MAIN GAME */}
      {gameState === 'playing' && currentProfile && (
        <>
          {/* HEADER */}
          <div className="bg-gray-900 border-b-4 border-gray-700 p-2 flex justify-between items-center z-20">
             <div className="flex items-center gap-2">
                <div className={`w-3 h-3 ${strategy === 'male' ? 'bg-blue-500 animate-pulse' : 'bg-pink-500 animate-pulse'}`}></div>
                <span className="text-[10px] text-gray-300">STRATEGY: {strategy === 'male' ? 'QUANTITY' : 'QUALITY'}</span>
             </div>
             <div className="text-yellow-400 text-sm">PTS: {score}</div>
          </div>

          {/* FEEDBACK OVERLAY */}
          {feedback && (
             <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/50 pointer-events-none">
                <div className={`border-4 ${feedback.includes('LOW') || feedback.includes('AVOIDED') ? 'border-red-500 bg-black text-red-500' : 'border-green-500 bg-black text-green-500'} p-4 text-xl animate-pop text-center`}>
                  {feedback}
                </div>
             </div>
          )}

          {/* MAIN DISPLAY */}
          <div className="flex-grow flex items-center justify-center p-4 bg-[url('https://www.transparenttextures.com/patterns/dark-matter.png')]">
             
             {/* THE CARD */}
             <div className="w-64 border-4 border-white bg-black relative shadow-[8px_8px_0px_0px_rgba(255,255,255,0.2)]">
                
                {/* IMAGE AREA */}
                <div className={`h-40 border-b-4 border-white flex items-center justify-center ${currentProfile.gender === 'male' ? 'bg-blue-900/30' : 'bg-pink-900/30'}`}>
                    <ProfileIcon size={64} className="text-white drop-shadow-[0_0_10px_rgba(255,255,255,0.8)]" />
                </div>

                {/* INFO AREA */}
                <div className="p-4 space-y-2">
                    <div className="flex justify-between items-baseline border-b-2 border-gray-700 pb-1">
                        <span className="text-white text-sm truncate">{currentProfile.name}</span>
                        <span className="text-gray-400 text-xs">{currentProfile.age}yo</span>
                    </div>
                    
                    <div className="flex items-center gap-2 text-[10px] text-green-400">
                        <Briefcase size={10} /> 
                        <span>{currentProfile.job}</span>
                    </div>

                    <div className="flex flex-wrap gap-1 mt-2">
                        {currentProfile.traits.map(t => (
                            <span key={t} className="bg-gray-800 text-gray-300 text-[8px] px-1 py-0.5 border border-gray-600">{t}</span>
                        ))}
                    </div>

                    <div className="mt-2 pt-2 border-t-2 border-gray-700">
                        <p className="text-[8px] text-gray-500 leading-tight">"{currentProfile.bio}"</p>
                    </div>
                </div>
             </div>

             {/* STREAK COUNTER - Floating */}
             {streak > 1 && (
                 <div className="absolute top-20 right-4 transform rotate-12 border-2 border-yellow-400 bg-black text-yellow-400 p-2 text-xs animate-bounce">
                     COMBO x{1 + Math.floor(streak / 3) * 0.5}
                 </div>
             )}

          </div>

          {/* CONTROLS */}
          <div className="bg-gray-900 border-t-4 border-gray-700 p-4 flex justify-between gap-4 z-20">
            <button onClick={() => handleSwipe('left')} className="flex-1 bg-red-900/50 border-4 border-red-500 text-red-500 py-3 hover:bg-red-500 hover:text-black transition-colors flex items-center justify-center gap-2 cursor-pointer">
                <X size={16}/> REJECT
            </button>
            <button onClick={() => handleSwipe('right')} className="flex-1 bg-green-900/50 border-4 border-green-500 text-green-500 py-3 hover:bg-green-500 hover:text-black transition-colors flex items-center justify-center gap-2 cursor-pointer">
                <Heart size={16}/> MATCH
            </button>
          </div>
        </>
      )}
    </div>
  );
};

const EssayPlanRevealL1: React.FC<{ isPresentation: boolean }> = ({ isPresentation }) => {
  const [revealed, setRevealed] = useState(false);
  return (
    <div className={`bg-gray-800/50 rounded-xl border border-gray-700 shadow-xl flex flex-col justify-center h-full ${isPresentation ? 'p-12' : 'p-8'}`}>
      <h3 className={`text-gray-400 font-bold uppercase tracking-widest mb-6 text-center ${isPresentation ? 'text-3xl' : 'text-base'}`}>Structure Planning</h3>
      {!revealed ? (
        <div className="flex flex-col items-center justify-center flex-grow space-y-4">
          <p className={`text-gray-400 text-center ${isPresentation ? 'text-2xl' : 'text-sm'}`}>Review the question on the left, then click to reveal the suggested structure.</p>
          <button onClick={() => setRevealed(true)} className={`group flex items-center gap-3 bg-pink-600 hover:bg-pink-500 text-white rounded-full font-bold transition-all shadow-lg hover:shadow-pink-500/25 ${isPresentation ? 'px-14 py-8 text-3xl' : 'px-8 py-4'}`}><Eye size={isPresentation ? 40 : 20} /> Reveal Paragraph Plan</button>
        </div>
      ) : (
        <div className="space-y-4 animate-fadeIn overflow-y-auto custom-scrollbar pr-2">
          <div className="flex justify-end"><button onClick={() => setRevealed(false)} className={`text-gray-500 hover:text-white flex items-center gap-1 uppercase font-bold ${isPresentation ? 'text-xl' : 'text-xs'}`}><EyeOff size={isPresentation ? 24 : 14}/> Hide</button></div>
          
          <div className={`flex gap-4 items-start bg-gray-900/80 rounded border border-gray-700 ${isPresentation ? 'p-6' : 'p-4'}`}>
              <div className={`rounded-full bg-blue-900 flex items-center justify-center font-bold text-blue-300 shrink-0 border border-blue-500 ${isPresentation ? 'w-16 h-16 text-2xl' : 'w-8 h-8 text-xs'}`}>P1</div>
              <div><strong className={`text-blue-300 block mb-1 ${isPresentation ? 'text-2xl' : 'text-sm'}`}>AO1: Evolutionary Theory</strong><p className={`text-gray-400 leading-relaxed ${isPresentation ? 'text-xl' : 'text-xs'}`}>Define Anisogamy. Explain how the difference in sex cells leads to different reproductive strategies: Inter-sexual selection (Quality/Female) vs Intra-sexual selection (Quantity/Male).</p></div>
          </div>

          <div className={`flex gap-4 items-start bg-gray-900/80 rounded border border-gray-700 ${isPresentation ? 'p-6' : 'p-4'}`}>
              <div className={`rounded-full bg-green-900 flex items-center justify-center font-bold text-green-300 shrink-0 border border-green-500 ${isPresentation ? 'w-16 h-16 text-2xl' : 'w-8 h-8 text-xs'}`}>P2</div>
              <div><strong className={`text-green-300 block mb-1 ${isPresentation ? 'text-2xl' : 'text-sm'}`}>AO3: Research Support (Buss)</strong><p className={`text-gray-400 leading-relaxed ${isPresentation ? 'text-xl' : 'text-xs'}`}><strong>Buss (1989):</strong> Surveyed 10,000 adults across 33 countries. Found universal patterns: Men valued youth/looks (fertility), Women valued resources/ambition. Supports evolutionary predictions.</p></div>
          </div>

          <div className={`flex gap-4 items-start bg-gray-900/80 rounded border border-gray-700 ${isPresentation ? 'p-6' : 'p-4'}`}>
              <div className={`rounded-full bg-green-900 flex items-center justify-center font-bold text-green-300 shrink-0 border border-green-500 ${isPresentation ? 'w-16 h-16 text-2xl' : 'w-8 h-8 text-xs'}`}>P3</div>
              <div><strong className={`text-green-300 block mb-1 ${isPresentation ? 'text-2xl' : 'text-sm'}`}>AO3: Research Support (Clark & Hatfield)</strong><p className={`text-gray-400 leading-relaxed ${isPresentation ? 'text-xl' : 'text-xs'}`}><strong>Clark & Hatfield (1989):</strong> Campus study. 75% of men agreed to casual sex request, 0% of women did. Strongly supports the prediction that females are the 'choosier' sex.</p></div>
          </div>

          <div className={`flex gap-4 items-start bg-gray-900/80 rounded border border-gray-700 ${isPresentation ? 'p-6' : 'p-4'}`}>
              <div className={`rounded-full bg-red-900 flex items-center justify-center font-bold text-red-300 shrink-0 border border-red-500 ${isPresentation ? 'w-16 h-16 text-2xl' : 'w-8 h-8 text-xs'}`}>P4</div>
              <div><strong className={`text-red-300 block mb-1 ${isPresentation ? 'text-2xl' : 'text-sm'}`}>AO3: Evaluation / Debate</strong><p className={`text-gray-400 leading-relaxed ${isPresentation ? 'text-xl' : 'text-xs'}`}><strong>Biological Determinism vs Social Change.</strong> The theory argues behaviour is hard-wired. However, Bereczkei et al. argue that social changes (women in workplace, contraception) have altered mate preferences, which the theory struggles to explain.</p></div>
          </div>
        </div>
      )}
    </div>
  );
};

// ==========================================
// 5. MAIN APP COMPONENT
// ==========================================

export default function App() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [currentLesson, setCurrentLesson] = useState(1); 
  const [isSidebarOpen, setSidebarOpen] = useState(true);
  const [isPresentation, setIsPresentation] = useState(false);
  const slideCount = 11; 

  const nextSlide = () => { if (currentSlide < slideCount - 1) setCurrentSlide(prev => prev + 1); };
  const prevSlide = () => { if (currentSlide > 0) setCurrentSlide(prev => prev - 1); };

  const togglePresentation = () => { 
    if (!isPresentation) {
        if (document.documentElement.requestFullscreen) document.documentElement.requestFullscreen().catch((e) => console.log(e));
        setSidebarOpen(false);
        setIsPresentation(true);
    } else {
        if (document.exitFullscreen && document.fullscreenElement) document.exitFullscreen().catch((e) => console.log(e));
        setIsPresentation(false);
    }
  };

  const renderLesson1 = () => {
    switch (currentSlide) {
      case 0: return (<Slide isPresentation={isPresentation}><div className="flex flex-col items-center justify-center h-full text-center"><div className="relative mb-8"><div className="absolute inset-0 bg-pink-500 blur-3xl opacity-20 rounded-full"></div><Heart size={isPresentation ? 180 : 120} className="text-pink-400 relative z-10" /></div><h1 className={`font-extrabold text-white mb-2 tracking-tight ${isPresentation ? 'text-9xl' : 'text-6xl'}`}>Relationships</h1><div className="h-1 w-32 bg-pink-600 my-6"></div><h2 className={`text-gray-400 font-light tracking-widest uppercase mb-12 ${isPresentation ? 'text-5xl' : 'text-2xl'}`}>Lesson 01: Evolutionary Explanations</h2><button onClick={nextSlide} className={`group relative bg-gray-800 text-white font-bold rounded-full overflow-hidden border border-pink-500/50 hover:border-pink-400 transition-all ${isPresentation ? 'px-16 py-8 text-4xl' : 'px-8 py-4'}`}><span className="relative z-10 flex items-center gap-2">Lesson Start <ChevronRight className="group-hover:translate-x-1 transition-transform"/></span><div className="absolute inset-0 bg-pink-600/20 translate-y-full group-hover:translate-y-0 transition-transform"></div></button></div></Slide>);
      case 1: return (<Slide isPresentation={isPresentation}><PhaseHeader phase="Phase 1: Activation" title="Do Now Task" icon={Clock} time="10 MINS" isPresentation={isPresentation} /><DoNowQuiz questions={lesson1DoNow} isPresentation={isPresentation} /></Slide>);
      case 2: return (<Slide isPresentation={isPresentation}><PhaseHeader phase="Phase 2: Teacher Input" title="Sexual Selection" icon={Dna} time="10 MINS" isPresentation={isPresentation} /><div className={`grid grid-cols-2 h-full ${isPresentation ? 'gap-12' : 'gap-8'}`}><div className={`bg-gray-800 rounded-xl border border-gray-700 flex flex-col ${isPresentation ? 'p-10' : 'p-8'}`}><h3 className={`font-bold text-white mb-4 ${isPresentation ? 'text-4xl' : 'text-2xl'}`}>Anisogamy</h3><p className={`text-gray-300 leading-relaxed mb-4 ${isPresentation ? 'text-2xl' : 'text-sm'}`}>The differences between male and female sex cells (gametes). <br/><br/><strong>Male Sperm:</strong> Highly mobile, created continuously in vast numbers, little energy required. <br/><strong>Female Eggs:</strong> Large, static, produced at intervals for limited years, huge energy investment.</p></div><div className={`bg-gray-800 rounded-xl border border-gray-700 flex flex-col ${isPresentation ? 'p-10' : 'p-8'}`}><h3 className={`font-bold text-white mb-4 ${isPresentation ? 'text-4xl' : 'text-2xl'}`}>Reproductive Strategy</h3><p className={`text-gray-300 leading-relaxed mb-4 ${isPresentation ? 'text-2xl' : 'text-sm'}`}><strong>Males:</strong> Quantity over Quality. Mating with as many females as possible increases reproductive success. <br/><br/><strong>Females:</strong> Quality over Quantity. Because eggs are rare (and pregnancy is costly), females must be choosier about their partner's genetic quality and resources.</p></div></div></Slide>);
      case 3: return (<Slide isPresentation={isPresentation}><PhaseHeader phase="Phase 2: Teacher Input" title="Selection Strategies" icon={GitMerge} time="15 MINS" isPresentation={isPresentation} /><div className={`grid grid-cols-2 h-full ${isPresentation ? 'gap-12' : 'gap-8'}`}><div className={`bg-blue-900/10 rounded-xl border-t-8 border-blue-500 shadow-xl flex flex-col ${isPresentation ? 'p-10' : 'p-8'}`}><h3 className={`font-bold text-blue-400 mb-4 ${isPresentation ? 'text-3xl' : 'text-xl'}`}>Intra-sexual Selection</h3><p className={`text-gray-300 leading-relaxed ${isPresentation ? 'text-2xl' : 'text-sm'}`}><strong>Male Strategy (Competition).</strong> Males compete with other males for access to females. The 'winner' passes on the genes that contributed to his victory (e.g. size, strength, aggression). This explains sexual dimorphism (why men are larger).</p></div><div className={`bg-pink-900/10 rounded-xl border-t-8 border-pink-500 shadow-xl flex flex-col ${isPresentation ? 'p-10' : 'p-8'}`}><h3 className={`font-bold text-pink-400 mb-4 ${isPresentation ? 'text-3xl' : 'text-xl'}`}>Inter-sexual Selection</h3><p className={`text-gray-300 leading-relaxed ${isPresentation ? 'text-2xl' : 'text-sm'}`}><strong>Female Strategy (Choice).</strong> Females choose the best available mate. They look for indicators of good genes ('Sexy Sons Hypothesis') and resources (provision). This drives males to display these traits.</p></div></div></Slide>);
      case 4: return (<Slide isPresentation={isPresentation}><PhaseHeader phase="Phase 2: Check" title="Mid-Lesson Check" icon={Activity} time="" isPresentation={isPresentation} /><AFLCheckL1 isPresentation={isPresentation} /></Slide>);
      case 5: return (<Slide isPresentation={isPresentation}><PhaseHeader phase="Phase 2: Teacher Input" title="Research Evidence (AO3)" icon={Search} time="10 MINS" isPresentation={isPresentation} /><div className={`grid grid-cols-2 h-full ${isPresentation ? 'gap-12' : 'gap-8'}`}><div className={`bg-gray-800 rounded-xl border border-gray-700 flex flex-col ${isPresentation ? 'p-10' : 'p-8'}`}><h3 className={`font-bold text-white mb-4 ${isPresentation ? 'text-4xl' : 'text-2xl'}`}>Buss (1989)</h3><p className={`text-gray-300 leading-relaxed ${isPresentation ? 'text-2xl' : 'text-sm'}`}><strong>Procedure:</strong> Surveyed over 10,000 adults in 33 countries asking about partner preferences.<br/><br/><strong>Findings:</strong> Universal agreement. Females placed greater value on resource-related characteristics (good financial prospects, ambition). Males valued reproductive capacity (youth, physical attractiveness).</p></div><div className={`bg-gray-800 rounded-xl border border-gray-700 flex flex-col ${isPresentation ? 'p-10' : 'p-8'}`}><h3 className={`font-bold text-white mb-4 ${isPresentation ? 'text-4xl' : 'text-2xl'}`}>Clark & Hatfield (1989)</h3><p className={`text-gray-300 leading-relaxed ${isPresentation ? 'text-2xl' : 'text-sm'}`}><strong>Procedure:</strong> Confederates approached students on a campus: "I find you very attractive. Would you go to bed with me?"<br/><br/><strong>Findings:</strong> 75% of men agreed immediately. 0% of women agreed. Supports the evolutionary prediction that females are choosier than males.</p></div></div></Slide>);
      case 6: return (<Slide isPresentation={isPresentation}><PhaseHeader phase="Phase 3: Guided Practice" title="Simulation Briefing" icon={Users} time="" isPresentation={isPresentation} /><div className="flex flex-col items-center justify-center h-full text-center max-w-2xl mx-auto"><div className={`rounded-full mb-8 animate-pulse bg-pink-900/20 ${isPresentation ? 'p-12' : 'p-6'}`}><Heart size={isPresentation ? 150 : 80} className="text-pink-400" /></div><h3 className={`font-bold text-white mb-6 ${isPresentation ? 'text-7xl' : 'text-4xl'}`}>EvoMatch</h3><p className={`text-gray-300 mb-8 leading-relaxed ${isPresentation ? 'text-4xl' : 'text-xl'}`}>Select your role and apply evolutionary theory to choose the 'best' partner. Maximise resources or reproductive success.</p><button onClick={nextSlide} className={`bg-pink-600 text-white rounded-full font-bold hover:bg-pink-500 transition-all shadow-lg ${isPresentation ? 'px-16 py-8 text-3xl' : 'px-10 py-4 text-lg'}`}>Enter Mating Market</button></div></Slide>);
      case 7: return (<Slide isPresentation={isPresentation}><PhaseHeader phase="Phase 3: Guided Practice (We Do)" title="Simulation: Partner Choice" icon={Heart} time="" isPresentation={isPresentation} /><EvoTinderSim isPresentation={isPresentation} /></Slide>);
      case 8: return (<Slide isPresentation={isPresentation}><PhaseHeader phase="Phase 4: Independent Practice" title="Essay Planning" icon={Layers} time="20 MINS" isPresentation={isPresentation} /><div className={`grid grid-cols-1 lg:grid-cols-2 h-full ${isPresentation ? 'gap-12' : 'gap-8'}`}><div className={`bg-gray-800 rounded-xl border border-gray-700 shadow-xl flex flex-col ${isPresentation ? 'p-12' : 'p-8'}`}><div className={`flex items-center gap-3 mb-6 border-b border-gray-600 pb-4`}><span className={`bg-pink-600 text-white font-bold rounded ${isPresentation ? 'px-4 py-2 text-xl' : 'px-3 py-1 text-sm'}`}>16 MARKS</span><h3 className={`font-bold text-gray-200 ${isPresentation ? 'text-4xl' : 'text-xl'}`}>Exam Question</h3></div><p className={`text-white font-semibold leading-snug mb-6 ${isPresentation ? 'text-4xl' : 'text-xl'}`}>"Discuss evolutionary explanations for partner preferences."</p><div className={`bg-black/30 rounded border-l-4 border-pink-500 mb-6 flex-grow ${isPresentation ? 'p-10' : 'p-4'}`}><h4 className={`text-pink-400 font-bold uppercase tracking-widest ${isPresentation ? 'text-lg' : 'text-xs'}`}>Key Content</h4><p className={`text-gray-300 leading-relaxed ${isPresentation ? 'text-2xl' : 'text-sm'}`}>Anisogamy, Inter/Intra-sexual selection, Buss, Clark & Hatfield.</p></div></div><EssayPlanRevealL1 isPresentation={isPresentation} /></div></Slide>);
      case 9: return (<Slide isPresentation={isPresentation}><div className="flex flex-col items-center justify-center h-full text-center"><div className={`bg-green-500/20 rounded-full mb-8 ${isPresentation ? 'p-12' : 'p-6'}`}><CheckCircle size={isPresentation ? 150 : 80} className="text-green-500" /></div><h2 className={`font-bold text-white mb-4 ${isPresentation ? 'text-7xl' : 'text-4xl'}`}>Lesson 01 Complete</h2><p className={`text-gray-400 mb-8 ${isPresentation ? 'text-4xl' : 'text-xl'}`}>You have mastered Evolutionary Theory.</p><div className={`bg-gray-800 rounded-xl border border-gray-700 ${isPresentation ? 'p-12' : 'p-6'}`}><h4 className={`text-pink-400 font-bold uppercase tracking-widest mb-2 ${isPresentation ? 'text-2xl' : 'text-xs'}`}>Next Lesson</h4><div className="flex items-center justify-between"><button className={`font-bold text-gray-500 cursor-not-allowed transition-colors ${isPresentation ? 'text-4xl' : 'text-xl'}`}>02: Physical Attractiveness (Locked)</button><ChevronRight className="text-gray-700" /></div></div></div></Slide>);
      default: return null;
    }
  };

  const renderLesson2 = () => null;
  const renderLesson3 = () => null;
  const renderLesson4 = () => null;
  const renderLesson5 = () => null;

  return (
    <div className="flex h-screen bg-gray-900 text-gray-100 font-sans overflow-hidden selection:bg-pink-500 selection:text-white">
      {/* Sidebar */}
      <div className={`${isSidebarOpen ? 'w-80' : 'w-0'} bg-gray-950 border-r border-gray-800 transition-all duration-300 flex flex-col z-20 shadow-2xl relative overflow-hidden`}><div className="p-6 border-b border-gray-800 flex justify-between items-center"><span className="font-black text-xl text-pink-500 tracking-tighter">RELATIONSHIPS</span><button onClick={() => setSidebarOpen(false)} className="text-gray-400 hover:text-white"><X size={20}/></button></div><div className="flex-grow overflow-y-auto py-4">{lessons.map((lesson) => (<button key={lesson.id} onClick={() => { if (lesson.active) { setCurrentLesson(lesson.id); setCurrentSlide(0); }}} className={`w-full text-left px-6 py-4 border-l-4 transition-all ${currentLesson === lesson.id ? 'border-pink-500 bg-pink-900/10 text-white shadow-[inset_10px_0_20px_-10px_rgba(236,72,153,0.2)]' : 'border-transparent text-gray-500 hover:bg-gray-900 hover:text-gray-300'} ${!lesson.active ? 'opacity-50 cursor-not-allowed' : ''}`}><div className="flex items-center justify-between"><span className="font-bold text-sm tracking-tight">{lesson.title}</span>{currentLesson === lesson.id && <div className="w-2 h-2 rounded-full bg-pink-500 shadow-[0_0_10px_rgba(236,72,153,1)]"></div>}</div></button>))}</div></div>
      <div className="flex-grow flex flex-col h-full relative bg-[#0a0a0a]">
        
        {/* TOP BAR */}
        <div className="absolute top-4 left-4 z-50 flex gap-2">{!isSidebarOpen && <button onClick={() => setSidebarOpen(true)} className="bg-gray-800 p-2 rounded text-white hover:bg-gray-700 shadow-lg border border-gray-700"><Menu size={20} /></button>}</div>
        <div className="absolute top-4 right-4 z-50 flex gap-2"><button onClick={togglePresentation} className={`p-2 rounded-full text-gray-400 hover:text-white hover:bg-gray-700 border border-gray-700/50 backdrop-blur-sm transition-all ${isPresentation ? 'bg-pink-600 text-white border-pink-500 shadow-[0_0_15px_rgba(236,72,153,0.5)]' : 'bg-gray-800/80'}`} title="Presentation Mode"><Projector size={20} /></button><button onClick={() => setSidebarOpen(!isSidebarOpen)} className="bg-gray-800/80 p-2 rounded-full text-gray-400 hover:text-white hover:bg-gray-700 border border-gray-700/50 backdrop-blur-sm transition-all" title={isSidebarOpen ? "Maximize Content" : "Show Sidebar"}>{isSidebarOpen ? <Maximize2 size={20} /> : <Minimize2 size={20} />}</button></div>
        
        {/* PROGRESS BAR */}
        <div className="h-1 bg-gray-900 w-full"><div className="h-full bg-gradient-to-r from-pink-800 to-pink-500 transition-all duration-500 shadow-[0_0_15px_rgba(236,72,153,0.5)]" style={{ width: `${((currentSlide + 1) / slideCount) * 100}%` }} /></div>
        
        {/* MAIN CONTENT AREA WITH ZOOM */}
        <main 
          className="flex-grow relative overflow-hidden bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-gray-900 via-[#050505] to-black"
          style={{ zoom: isPresentation ? "1.25" : "1" }}
        >
            {currentLesson === 1 && renderLesson1()}
            {currentLesson === 2 && renderLesson2()}
            {currentLesson === 3 && renderLesson3()}
            {currentLesson === 4 && renderLesson4()}
            {currentLesson === 5 && renderLesson5()}
        </main>
        
        {/* BOTTOM NAV */}
        <div className="h-20 border-t border-gray-800 bg-black/50 backdrop-blur-sm flex items-center justify-between px-8 z-10"><button onClick={() => currentSlide > 0 && setCurrentSlide(prev => prev - 1)} disabled={currentSlide === 0} className={`flex items-center gap-2 px-6 py-3 rounded-lg font-bold text-sm transition-all ${currentSlide === 0 ? 'text-gray-700 cursor-not-allowed' : 'text-gray-400 hover:text-white hover:bg-gray-800'}`}><ChevronLeft size={16} /> PREV</button><span className="text-gray-600 font-mono text-xs tracking-widest">{currentSlide + 1} / {slideCount}</span><button onClick={() => currentSlide < (slideCount - 1) && setCurrentSlide(prev => prev + 1)} disabled={currentSlide === (slideCount - 1)} className={`flex items-center gap-2 px-6 py-3 rounded-lg font-bold text-sm transition-all ${currentSlide === (slideCount - 1) ? 'text-gray-700 cursor-not-allowed' : 'bg-pink-600 text-white hover:bg-pink-500 shadow-lg hover:shadow-pink-500/20'}`}>NEXT <ChevronRight size={16} /></button></div>
      </div>
    </div>
  );
}